package ci.oda.jury_pro.controllers;

import java.io.IOException;
import java.util.List;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import ci.oda.jury_pro.entities.Evenement;
import ci.oda.jury_pro.services.EvenementsService;
import ci.oda.jury_pro.services.IParticipantService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class EvenementController {

    @Autowired
    private EvenementsService evenementsService;

    @GetMapping("/evenements")
    public List<IParticipantService> getAllEvenements() {

        return evenementsService.getEvents();

    }

    @GetMapping("/evenements/{evenementId}")
    public Evenement getEvenementById(@PathVariable Long evenementId) {

        return evenementsService.getEvenementById(evenementId);
    }

    @GetMapping("/evenement/jury/{juryId}")
    public Evenement getEvenementByJuryId(@PathVariable Long juryId) {

        return evenementsService.GetEventByJuryId(juryId);
    }

    @PostMapping("/evenements")
    public Evenement createOrUpdateEvenement(@RequestParam("evenement") String model,
            @RequestParam("file") MultipartFile file) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        Evenement modelDTO = mapper.readValue(model, Evenement.class);

        modelDTO.setEvenementPhoto(file.getBytes());
        Evenement result = evenementsService.createOrUpdateEvenement(modelDTO);

        return result;
    }

    @DeleteMapping("/evenements/{evenementId}")
    public ResponseEntity<?> delete(@PathVariable Long evenementId) {
        ResponseEntity<?> result = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        try {

            evenementsService.deleteEvenement(evenementId);
            result = new ResponseEntity<>(HttpStatus.OK);

        } catch (Exception e) {

            System.err.println(e.getMessage());
        }
        return result;
    }
}
