package ci.oda.jury_pro.services;

public interface resultGroupeByEvent {

    public Long getGroupe_id();

    public String getGroupe_nom();

    public Long getMoyenne();

}
