package ci.oda.jury_pro.entities;

import javax.persistence.*;

@Entity
@Table(name = "vote_candidats")
public class Vote_candidats {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long voteCandidatId;

    @ManyToOne
    private Jury jury;

    @ManyToOne
    private Evenement evenement;

    @ManyToOne
    private Candidats candidat;

    @ManyToOne
    private Criteres critere;

    private int note;


    public Long getVoteCandidatId() {
        return this.voteCandidatId;
    }

    public void setVoteCandidatId(Long voteCandidatId) {
        this.voteCandidatId = voteCandidatId;
    }

    public Jury getJury() {
        return this.jury;
    }

    public void setJury(Jury jury) {
        this.jury = jury;
    }

    public Evenement getEvenement() {
        return this.evenement;
    }

    public void setEvenement(Evenement evenement) {
        this.evenement = evenement;
    }

    public Candidats getCandidat() {
        return this.candidat;
    }

    public void setCandidat(Candidats candidat) {
        this.candidat = candidat;
    }

    public Criteres getCritere() {
        return this.critere;
    }

    public void setCritere(Criteres critere) {
        this.critere = critere;
    }

    public int getNote() {
        return this.note;
    }

    public void setNote(int note) {
        this.note = note;
    }


    @Override
    public String toString() {
        return "{" +
            " voteCandidatId='" + getVoteCandidatId() + "'" +
            ", jury='" + getJury() + "'" +
            ", evenement='" + getEvenement() + "'" +
            ", candidat='" + getCandidat() + "'" +
            ", critere='" + getCritere() + "'" +
            ", note='" + getNote() + "'" +
            "}";
    }
    

}
