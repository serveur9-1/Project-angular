package ci.oda.jury_pro.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ci.oda.jury_pro.entities.Vote_candidats;
import ci.oda.jury_pro.entities.Vote_groupes;
import ci.oda.jury_pro.repositories.VoteCandidatsRepository;
import ci.oda.jury_pro.repositories.voteGroupesRepository;

@Service
public class VoteGroupeOrCandidatServices {
    @Autowired
    private VoteCandidatsRepository voteCandidatsRepository;

    public List<Vote_candidats> getAllVotesCandidats() {

        return voteCandidatsRepository.findAll();

    }

    public Vote_candidats getVoteCandidatById(Long voteCandidatId) {

        Optional<Vote_candidats> item = voteCandidatsRepository.findById(voteCandidatId);
        if (item.isPresent()) {
            return item.get();
        }
        return null;
    }

    public List<resultatByEvent> getResultat(Long eventId) {

        return voteCandidatsRepository.getResultatByEvents(eventId);

    }

    public Vote_candidats getVoteCandidatByAllInfo(Long evenementId, Long juryId, Long candidatId, Long critereId) {

        Optional<Vote_candidats> item = voteCandidatsRepository.findNoteCandidByAllInfo(evenementId, juryId, candidatId,
                critereId);
        if (item.isPresent()) {
            return item.get();
        }
        return null;
    }

    public Boolean createOrUpdateVoteCandidat(Vote_candidats vote_candidats) {

        Boolean result = false;

        try {

            voteCandidatsRepository.save(vote_candidats);
            result = true;

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return result;

    }

    public boolean deleteVoteCandidat(Long voteCandidatId) {

        Boolean result = false;
        try {

            if (voteCandidatId <= 0) {
                throw new Exception();
            }
            voteCandidatsRepository.deleteById(voteCandidatId);

            result = true;

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return result;
    }

    @Autowired
    private voteGroupesRepository voteGroupesRepository;

    public List<Vote_groupes> getAllVotesGroupes() {

        return voteGroupesRepository.findAll();

    }

    public Vote_groupes getVoteGroupesById(Long voteGroupeId) {

        Optional<Vote_groupes> item = voteGroupesRepository.findById(voteGroupeId);
        if (item.isPresent()) {
            return item.get();
        }
        return null;
    }

    public List<resultGroupeByEvent> getResultatGroup(Long eventId) {

        return voteGroupesRepository.getResultatGroupByEvents(eventId);

    }

    public Vote_groupes getVoteGroupeByAllInfo(Long evenementId, Long juryId, Long groupeId, Long critereId) {

        Optional<Vote_groupes> item = voteGroupesRepository.findNoteGroupByAllInfo(evenementId, juryId, groupeId,
                critereId);
        if (item.isPresent()) {
            return item.get();
        }
        return null;
    }

    public Boolean createOrUpdateVoteGroupe(Vote_groupes vote_groupes) {

        Boolean result = false;

        try {

            voteGroupesRepository.save(vote_groupes);
            result = true;

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return result;

    }

    public boolean deleteVoteGroupe(Long voteGroupeId) {

        Boolean result = false;
        try {

            if (voteGroupeId <= 0) {
                throw new Exception();
            }
            voteGroupesRepository.deleteById(voteGroupeId);

            result = true;

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return result;
    }
}
