package ci.oda.jury_pro.services;

public interface IParticipantService {

    public Long getEvenement_id();

    public String getEvenement_nom();

    public String getEvenement_type();

    public byte[] getEvenement_photo();

    public String getEvenement_date_debut();

    public String getEvenement_date_fin();

    public Long getParticipant();

}
