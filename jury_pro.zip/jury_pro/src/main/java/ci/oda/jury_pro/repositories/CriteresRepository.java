package ci.oda.jury_pro.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ci.oda.jury_pro.entities.Criteres;

public interface CriteresRepository extends JpaRepository<Criteres, Long> {

    @Query(value = "SELECT * FROM criteres WHERE evenement_evenement_id = :evenementId", nativeQuery = true)
    List<Criteres> findByEventId(@Param("evenementId") Long evenementId);
}
