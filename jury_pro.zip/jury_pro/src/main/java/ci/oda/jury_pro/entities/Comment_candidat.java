package ci.oda.jury_pro.entities;

import javax.persistence.*;

@Entity
@Table(name = "commentaire_candidat")
public class Comment_candidat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long commentaireCandidatId;

    private String commentaire;

    @ManyToOne
    private Candidats candidats;

    @ManyToOne
    private Evenement evenement;

    @ManyToOne
    private Jury jury;

    public Long getCommentaireCandidatId() {
        return this.commentaireCandidatId;
    }

    public void setCommentaireCandidatId(Long commentaireCandidatId) {
        this.commentaireCandidatId = commentaireCandidatId;
    }

    public String getCommentaire() {
        return this.commentaire;
    }

    public void setCommentaire(String commentaire) {
        this.commentaire = commentaire;
    }

    public Candidats getCandidats() {
        return this.candidats;
    }

    public void setCandidats(Candidats candidats) {
        this.candidats = candidats;
    }

    public Evenement getEvenement() {
        return this.evenement;
    }

    public void setEvenement(Evenement evenement) {
        this.evenement = evenement;
    }

    public Jury getJury() {
        return this.jury;
    }

    public void setJury(Jury jury) {
        this.jury = jury;
    }

    @Override
    public String toString() {
        return "{" + " commentaireCandidatId='" + getCommentaireCandidatId() + "'" + ", commentaire='"
                + getCommentaire() + "'" + ", candidats='" + getCandidats() + "'" + ", evenement='" + getEvenement()
                + "'" + ", jury='" + getJury() + "'" + "}";
    }

}
