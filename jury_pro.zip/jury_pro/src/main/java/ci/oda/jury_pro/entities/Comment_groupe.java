package ci.oda.jury_pro.entities;

import javax.persistence.*;

@Entity
@Table(name = "commentaire_groupe")
public class Comment_groupe {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long commentaireGroupeId;

    private String commentaire;

    @ManyToOne
    private Groupes groupes;

    @ManyToOne
    private Evenement evenement;

    @ManyToOne
    private Jury jury;

    public Long getCommentaireGroupeId() {
        return this.commentaireGroupeId;
    }

    public void setCommentaireGroupeId(Long commentaireGroupeId) {
        this.commentaireGroupeId = commentaireGroupeId;
    }

    public String getCommentaire() {
        return this.commentaire;
    }

    public void setCommentaire(String commentaire) {
        this.commentaire = commentaire;
    }

    public Groupes getGroupes() {
        return this.groupes;
    }

    public void setGroupes(Groupes groupes) {
        this.groupes = groupes;
    }

    public Evenement getEvenement() {
        return this.evenement;
    }

    public void setEvenement(Evenement evenement) {
        this.evenement = evenement;
    }

    public Jury getJury() {
        return this.jury;
    }

    public void setJury(Jury jury) {
        this.jury = jury;
    }

}
