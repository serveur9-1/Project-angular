package ci.oda.jury_pro.controllers;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import ci.oda.jury_pro.entities.Groupes;
import ci.oda.jury_pro.services.GroupesService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class GroupeController {
    @Autowired
    private GroupesService groupesService;

    @GetMapping("/groupes")
    public List<Groupes> getAllGroupes() {

        return groupesService.getAllGroupes();

    }

    @GetMapping("/groupe/{groupeId}")
    public Groupes getEvenementById(@PathVariable Long groupeId) {

        return groupesService.getGroupeById(groupeId);
    }

    @GetMapping("/groupe/event/{evenementId}")
    public List<Groupes> getGroupeByEventID(@PathVariable Long evenementId) {

        return groupesService.getGroupeByEventID(evenementId);
    }

    @PostMapping("/groupe")
    public Groupes createOrUpdateGroupes(@RequestParam("groupe") String model, @RequestParam("file") MultipartFile file)
            throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        Groupes modelDTO = mapper.readValue(model, Groupes.class);

        modelDTO.setGroupePhoto(file.getBytes());
        Groupes result = groupesService.createOrUpdateGroupe(modelDTO);

        return result;
    }

    @DeleteMapping("/groupe/{groupeId}")
    public ResponseEntity<?> delete(@PathVariable Long groupeId) {
        ResponseEntity<?> result = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        try {

            groupesService.deleteGroupe(groupeId);
            result = new ResponseEntity<>(HttpStatus.OK);

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return result;
    }
}
