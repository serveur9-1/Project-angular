package ci.oda.jury_pro.services;

public interface resultatByEvent {

    public Long getCandidat_id();

    public String getCandidat_nom();

    public String getCandidat_prenoms();

    public Long getMoyenne();
}
