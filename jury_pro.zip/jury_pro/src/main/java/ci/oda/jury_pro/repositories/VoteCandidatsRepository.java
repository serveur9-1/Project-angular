package ci.oda.jury_pro.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import ci.oda.jury_pro.services.resultatByEvent;
import ci.oda.jury_pro.entities.Vote_candidats;

public interface VoteCandidatsRepository extends JpaRepository<Vote_candidats, Long> {

    @Query(value = "SELECT * FROM vote_candidats WHERE evenement_evenement_id = :evenementId AND jury_jury_id = :juryId AND candidat_candidat_id = :candidatId AND critere_critere_id = :critereId", nativeQuery = true)
    Optional<Vote_candidats> findNoteCandidByAllInfo(@Param("evenementId") Long evenementId,
            @Param("juryId") Long juryId, @Param("candidatId") Long candidatId, @Param("critereId") Long critereId);

    @Query(value = "SELECT candidat_id,candidat_nom,candidat_prenoms,COALESCE(SUM(note),0) as Moyenne FROM candidats LEFT JOIN vote_candidats ON vote_candidats.candidat_candidat_id=candidats.candidat_id WHERE candidats.evenement_evenement_id=:eventId GROUP BY candidats.candidat_id ORDER BY moyenne DESC", nativeQuery = true)
    public List<resultatByEvent> getResultatByEvents(@Param("eventId") Long eventId);
}
