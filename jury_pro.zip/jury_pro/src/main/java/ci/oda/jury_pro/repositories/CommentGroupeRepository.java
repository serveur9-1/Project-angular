package ci.oda.jury_pro.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ci.oda.jury_pro.entities.Comment_groupe;

public interface CommentGroupeRepository extends JpaRepository<Comment_groupe, Long> {

    @Query(value = "SELECT * FROM commentaire_groupe WHERE evenement_evenement_id = :evenementId AND jury_jury_id = :juryId AND groupes_groupe_id = :groupeId", nativeQuery = true)
    Optional<Comment_groupe> findCommentGroupeByAllInfo(@Param("evenementId") Long evenementId,
            @Param("juryId") Long juryId, @Param("groupeId") Long groupeId);

}
