package ci.oda.jury_pro.controllers;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import ci.oda.jury_pro.entities.Candidats;
import ci.oda.jury_pro.services.CandidatsService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")

public class CandidatController {
    @Autowired
    private CandidatsService candidatsService;

    @GetMapping("/candidats")
    public List<Candidats> getAllCandidats() {

        return candidatsService.getAllCandidats();

    }

    @GetMapping("/candidat/{candidatId}")
    public Candidats getCandidatById(@PathVariable Long candidatId) {

        return candidatsService.getCandidatById(candidatId);
    }

    @GetMapping("/candidat/event/{evenementId}")
    public List<Candidats> getCandidatByEventId(@PathVariable Long evenementId) {

        return candidatsService.getCandidatByEventID(evenementId);
    }

    @PostMapping("/candidat")
    public Candidats createOrUpdateCandidat(@RequestParam("candidat") String model,
            @RequestParam("file") MultipartFile file) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        Candidats modelDTO = mapper.readValue(model, Candidats.class);

        modelDTO.setCandidatPhoto(file.getBytes());
        Candidats result = candidatsService.createOrUpdateCandidat(modelDTO);

        return result;
    }

    @DeleteMapping("/candidat/{candidatId}")
    public ResponseEntity<?> delete(@PathVariable Long candidatId) {
        ResponseEntity<?> result = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        try {

            candidatsService.deleteCandidat(candidatId);
            result = new ResponseEntity<>(HttpStatus.OK);

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return result;
    }
}
