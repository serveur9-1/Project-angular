package ci.oda.jury_pro.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import ci.oda.jury_pro.entities.Jury;
import ci.oda.jury_pro.services.JuryService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class JuryController {

    @Autowired
    private JuryService juryService;

    @GetMapping("/juries")
    public List<Jury> getAllJuries() {

        return juryService.getAllJuries();

    }

    @GetMapping("/jury/{juryId}")
    public Jury getJuryById(@PathVariable Long juryId) {

        return juryService.getJuryById(juryId);
    }

    @GetMapping("/jury/event/{evenementId}")
    public List<Jury> getJuryByEventId(@PathVariable Long evenementId) {

        return juryService.getJuryByEventId(evenementId);
    }

    @PostMapping("/jury")
    public ResponseEntity<?> createOrUpdateJury(@RequestBody Jury jury) {

        ResponseEntity<?> result = new ResponseEntity<>(HttpStatus.BAD_REQUEST);

        try {
            if (!juryService.createOrUpdateJury(jury)) {
                throw new Exception();
            }

            result = new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return result;
    }

    @GetMapping("/jury/number/{number}")
    public Long getJuryByNumber(@PathVariable Long number) {

        return juryService.findByNumero(number);
    }

    @DeleteMapping("/jury/{juryId}")
    public ResponseEntity<?> delete(@PathVariable Long juryId) {
        ResponseEntity<?> result = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        try {

            juryService.deleteJury(juryId);
            result = new ResponseEntity<>(HttpStatus.OK);

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return result;
    }
}
