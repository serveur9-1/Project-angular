package ci.oda.jury_pro.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ci.oda.jury_pro.entities.Comment_candidat;

public interface CommentCandidatRepository extends JpaRepository<Comment_candidat, Long> {

    @Query(value = "SELECT * FROM commentaire_candidat WHERE evenement_evenement_id = :evenementId AND jury_jury_id = :juryId AND candidats_candidat_id = :candidatId", nativeQuery = true)
    Optional<Comment_candidat> findCommentByAllInfo(@Param("evenementId") Long evenementId,
            @Param("juryId") Long juryId, @Param("candidatId") Long candidatId);
}
