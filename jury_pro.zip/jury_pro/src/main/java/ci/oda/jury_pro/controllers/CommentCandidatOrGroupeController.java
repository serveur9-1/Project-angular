package ci.oda.jury_pro.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import ci.oda.jury_pro.entities.Comment_candidat;
import ci.oda.jury_pro.entities.Comment_groupe;
import ci.oda.jury_pro.services.CommentGroupeOrCandidatService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class CommentCandidatOrGroupeController {

    @Autowired
    private CommentGroupeOrCandidatService commentGroupeOrCandidatService;

    @GetMapping("/comment_candidats")
    public List<Comment_candidat> getAllCommentCandidats() {

        return commentGroupeOrCandidatService.getAllCommentCandidats();

    }

    @GetMapping("/comment_candidat/{commentCandidatID}")
    public Comment_candidat getCommentCandidatById(@PathVariable Long commentCandidatID) {

        return commentGroupeOrCandidatService.getCommentCandidatById(commentCandidatID);
    }

    @GetMapping("/comment_candidat/{evenementId}/{juryId}/{candidatId}")
    public Comment_candidat getCommentCandidatByAllInfo(@PathVariable Long evenementId, @PathVariable Long juryId,
            @PathVariable Long candidatId) {

        return commentGroupeOrCandidatService.getCommentCandidatByAllInfo(evenementId, juryId, candidatId);
    }

    @PostMapping("/comment_candidat")
    public ResponseEntity<?> createOrUpdateCommentCandidat(@RequestBody Comment_candidat comment_candidat) {

        ResponseEntity<?> result = new ResponseEntity<>(HttpStatus.BAD_REQUEST);

        try {
            if (!commentGroupeOrCandidatService.createOrUpdateCommentCandidat(comment_candidat)) {
                throw new Exception();
            }

            result = new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return result;
    }

    @DeleteMapping("/comment_candidat/delete/{commentCandidatID}")
    public ResponseEntity<?> deleteCommentCandidat(@PathVariable Long commentCandidatID) {
        ResponseEntity<?> result = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        try {

            commentGroupeOrCandidatService.deleteCommentCandidat(commentCandidatID);
            result = new ResponseEntity<>(HttpStatus.OK);

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return result;
    }

    /* CRUD TO GROUPE */

    @GetMapping("/comment_groupes")
    public List<Comment_groupe> getAllCommentGroupes() {

        return commentGroupeOrCandidatService.getAllCommentGroupes();

    }

    @GetMapping("/comment_groupe/{commentGroupeID}")
    public Comment_groupe getCommentGroupeById(@PathVariable Long commentGroupeID) {

        return commentGroupeOrCandidatService.getCommentGroupesById(commentGroupeID);
    }

    @GetMapping("/comment_groupe/{evenementId}/{juryId}/{groupeId}")
    public Comment_groupe getCommentGroupeByAllInfo(@PathVariable Long evenementId, @PathVariable Long juryId,
            @PathVariable Long groupeId) {

        return commentGroupeOrCandidatService.getCommentGroupeByAllInfo(evenementId, juryId, groupeId);
    }

    @PostMapping("/comment_groupe")
    public ResponseEntity<?> createOrUpdateCommentGroupe(@RequestBody Comment_groupe comment_groupe) {

        ResponseEntity<?> result = new ResponseEntity<>(HttpStatus.BAD_REQUEST);

        try {
            if (!commentGroupeOrCandidatService.createOrUpdateCommentGroupe(comment_groupe)) {
                throw new Exception();
            }

            result = new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return result;
    }

    @DeleteMapping("/comment_groupe/{commentGroupeID}")
    public ResponseEntity<?> deleteCommentGroupe(@PathVariable Long commentGroupeID) {
        ResponseEntity<?> result = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        try {

            commentGroupeOrCandidatService.deleteCommentGroupe(commentGroupeID);
            result = new ResponseEntity<>(HttpStatus.OK);

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return result;
    }

}
