package ci.oda.jury_pro.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ci.oda.jury_pro.entities.Groupes;

public interface GroupesRepository extends JpaRepository<Groupes, Long> {

    @Query(value = "SELECT * FROM groupes WHERE evenement_evenement_id = :evenementId", nativeQuery = true)
    List<Groupes> findGroupeByEventId(@Param("evenementId") Long evenementId);
}
