package ci.oda.jury_pro.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import ci.oda.jury_pro.entities.Vote_candidats;
import ci.oda.jury_pro.entities.Vote_groupes;
import ci.oda.jury_pro.services.VoteGroupeOrCandidatServices;
import ci.oda.jury_pro.services.resultGroupeByEvent;
import ci.oda.jury_pro.services.resultatByEvent;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class VotesGroupeOrCandidatController {
    @Autowired
    private VoteGroupeOrCandidatServices voteGroupeOrCandidatServices;

    @GetMapping("/vote_candidats")
    public List<Vote_candidats> getAllVoteCandidats() {

        return voteGroupeOrCandidatServices.getAllVotesCandidats();

    }

    @GetMapping("/resultat/{eventId}")
    public List<resultatByEvent> getResultat(@PathVariable Long eventId) {

        return voteGroupeOrCandidatServices.getResultat(eventId);

    }

    @GetMapping("/vote_candidat/{voteCandidatID}")
    public Vote_candidats getVoteCandidatById(@PathVariable Long voteCandidatID) {

        return voteGroupeOrCandidatServices.getVoteCandidatById(voteCandidatID);
    }

    @GetMapping("/vote_candidat/{evenementId}/{juryId}/{candidatId}/{critereId}")
    public Vote_candidats getNoteCandidatByAllInfo(@PathVariable Long evenementId, @PathVariable Long juryId,
            @PathVariable Long candidatId, @PathVariable Long critereId) {

        return voteGroupeOrCandidatServices.getVoteCandidatByAllInfo(evenementId, juryId, candidatId, critereId);
    }

    @PostMapping("/vote_candidat")
    public ResponseEntity<?> createOrUpdateVoteCandidat(@RequestBody Vote_candidats vote_candidats) {

        ResponseEntity<?> result = new ResponseEntity<>(HttpStatus.BAD_REQUEST);

        try {
            if (!voteGroupeOrCandidatServices.createOrUpdateVoteCandidat(vote_candidats)) {
                throw new Exception();
            }

            result = new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return result;
    }

    @DeleteMapping("/vote_candidat/{voteCandidatID}")
    public ResponseEntity<?> deleteCandidat(@PathVariable Long voteCandidatID) {
        ResponseEntity<?> result = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        try {

            voteGroupeOrCandidatServices.deleteVoteCandidat(voteCandidatID);
            result = new ResponseEntity<>(HttpStatus.OK);

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return result;
    }

    /* CRUD TO GROUPE */

    @GetMapping("/vote_groupes")
    public List<Vote_groupes> getAllVoteGroupes() {

        return voteGroupeOrCandidatServices.getAllVotesGroupes();

    }

    @GetMapping("/vote_groupe/{voteGroupeID}")
    public Vote_groupes getVoteGroupeById(@PathVariable Long voteGroupeID) {

        return voteGroupeOrCandidatServices.getVoteGroupesById(voteGroupeID);
    }

    @GetMapping("/vote_groupe/{evenementId}/{juryId}/{groupeId}/{critereId}")
    public Vote_groupes getNoteGroupeByAllInfo(@PathVariable Long evenementId, @PathVariable Long juryId,
            @PathVariable Long groupeId, @PathVariable Long critereId) {

        return voteGroupeOrCandidatServices.getVoteGroupeByAllInfo(evenementId, juryId, groupeId, critereId);
    }

    @GetMapping("/resultatGroupe/{eventId}")
    public List<resultGroupeByEvent> getResultgroupByEvent(@PathVariable Long eventId) {

        return voteGroupeOrCandidatServices.getResultatGroup(eventId);

    }

    @PostMapping("/vote_groupe")
    public ResponseEntity<?> createOrUpdateVoteGroupe(@RequestBody Vote_groupes vote_groupes) {

        ResponseEntity<?> result = new ResponseEntity<>(HttpStatus.BAD_REQUEST);

        try {
            if (!voteGroupeOrCandidatServices.createOrUpdateVoteGroupe(vote_groupes)) {
                throw new Exception();
            }

            result = new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return result;
    }

    @DeleteMapping("/vote_groupe/{voteGroupeID}")
    public ResponseEntity<?> deleteGroupe(@PathVariable Long voteGroupeID) {
        ResponseEntity<?> result = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        try {

            voteGroupeOrCandidatServices.deleteVoteGroupe(voteGroupeID);
            result = new ResponseEntity<>(HttpStatus.OK);

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return result;
    }

}
