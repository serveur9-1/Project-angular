package ci.oda.jury_pro.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ci.oda.jury_pro.entities.Groupes;
import ci.oda.jury_pro.repositories.GroupesRepository;

@Service
public class GroupesService {
    @Autowired
    private GroupesRepository groupesRepository;

    public List<Groupes> getAllGroupes() {

        return groupesRepository.findAll();

    }

    public Groupes getGroupeById(Long groupeId) {
        Optional<Groupes> item = groupesRepository.findById(groupeId);
        if (item.isPresent()) {
            return item.get();
        }
        return null;
    }

    public List<Groupes> getGroupeByEventID(Long evenementId) {

        List<Groupes> item = groupesRepository.findGroupeByEventId(evenementId);

        return item;
    }

    public Groupes createOrUpdateGroupe(Groupes groupes) {

        Groupes result = groupes;

        try {
            if (groupes.getGroupeId() < 0) {
                Groupes item = groupesRepository.getOne(groupes.getGroupeId());
                if (item == null) {
                    throw new Exception();
                } else {
                    groupesRepository.save(groupes);
                    result = groupes;
                }

            } else if (groupes.getGroupeId() > 0) {
                groupesRepository.save(groupes);
                result = groupes;

            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return result;
    }

    public boolean deleteGroupe(Long groupeId) {

        Boolean result = false;
        try {

            if (groupeId == 0) {
                throw new Exception();
            }
            groupesRepository.deleteById(groupeId);

            result = true;

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return result;
    }
}
