package ci.oda.jury_pro.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import ci.oda.jury_pro.services.resultGroupeByEvent;
import ci.oda.jury_pro.entities.Vote_groupes;

public interface voteGroupesRepository extends JpaRepository<Vote_groupes, Long> {

    @Query(value = "SELECT * FROM vote_groupes WHERE evenement_evenement_id = :evenementId AND jury_jury_id = :juryId AND groupe_groupe_id = :groupeId AND critere_critere_id = :critereId", nativeQuery = true)
    Optional<Vote_groupes> findNoteGroupByAllInfo(@Param("evenementId") Long evenementId, @Param("juryId") Long juryId,
            @Param("groupeId") Long groupeId, @Param("critereId") Long critereId);

    @Query(value = "SELECT groupe_id,groupe_nom,COALESCE(SUM(note),0) as Moyenne FROM groupes LEFT JOIN vote_groupes ON vote_groupes.groupe_groupe_id=groupes.groupe_id WHERE groupes.evenement_evenement_id=:eventId GROUP BY groupes.groupe_id ORDER BY Moyenne DESC", nativeQuery = true)
    public List<resultGroupeByEvent> getResultatGroupByEvents(@Param("eventId") Long eventId);

}
