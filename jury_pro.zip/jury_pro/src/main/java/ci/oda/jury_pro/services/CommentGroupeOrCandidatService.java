package ci.oda.jury_pro.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ci.oda.jury_pro.entities.Comment_candidat;
import ci.oda.jury_pro.entities.Comment_groupe;
import ci.oda.jury_pro.repositories.CommentCandidatRepository;
import ci.oda.jury_pro.repositories.CommentGroupeRepository;

@Service
public class CommentGroupeOrCandidatService {

    @Autowired
    private CommentCandidatRepository commentCandidatRepository;

    public List<Comment_candidat> getAllCommentCandidats() {

        return commentCandidatRepository.findAll();

    }

    public Comment_candidat getCommentCandidatById(Long CommentCandidatId) {

        Optional<Comment_candidat> item = commentCandidatRepository.findById(CommentCandidatId);
        if (item.isPresent()) {
            return item.get();
        }
        return null;
    }

    public Comment_candidat getCommentCandidatByAllInfo(Long evenementId, Long juryId, Long candidatId) {

        Optional<Comment_candidat> item = commentCandidatRepository.findCommentByAllInfo(evenementId, juryId,
                candidatId);
        if (item.isPresent()) {
            return item.get();
        }
        return null;
    }

    public Boolean createOrUpdateCommentCandidat(Comment_candidat comment_candidat) {

        Boolean result = false;
        Optional<Comment_candidat> comment = commentCandidatRepository.findCommentByAllInfo(
                comment_candidat.getEvenement().getEvenementId(), comment_candidat.getJury().getJuryId(),
                comment_candidat.getCandidats().getCandidatId());

        try {
            if (comment != null) {

                commentCandidatRepository.save(comment_candidat);
                result = true;

            } else {
                commentCandidatRepository.save(comment_candidat);
                result = true;

            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return result;

    }

    public boolean deleteCommentCandidat(Long commentCandidatId) {

        Boolean result = false;
        try {

            if (commentCandidatId <= 0) {
                throw new Exception();
            }
            commentCandidatRepository.deleteById(commentCandidatId);

            result = true;

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return result;
    }

    @Autowired
    private CommentGroupeRepository commentGroupeRepository;

    public List<Comment_groupe> getAllCommentGroupes() {

        return commentGroupeRepository.findAll();

    }

    public Comment_groupe getCommentGroupesById(Long commentGroupeId) {

        Optional<Comment_groupe> item = commentGroupeRepository.findById(commentGroupeId);
        if (item.isPresent()) {
            return item.get();
        }
        return null;
    }

    public Comment_groupe getCommentGroupeByAllInfo(Long evenementId, Long juryId, Long groupeId) {

        Optional<Comment_groupe> item = commentGroupeRepository.findCommentGroupeByAllInfo(evenementId, juryId,
                groupeId);
        if (item.isPresent()) {
            return item.get();
        }
        return null;
    }

    public Boolean createOrUpdateCommentGroupe(Comment_groupe comment_groupe) {

        Boolean result = false;

        try {
            if (comment_groupe.getCommentaireGroupeId() < 0) {
                Comment_groupe item = commentGroupeRepository.getOne(comment_groupe.getCommentaireGroupeId());
                if (item == null) {
                    result = false;
                    throw new Exception();
                } else {
                    commentGroupeRepository.save(comment_groupe);
                    result = true;
                }

            } else if (comment_groupe.getCommentaireGroupeId() > 0) {
                commentGroupeRepository.save(comment_groupe);
                result = true;

            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return result;

    }

    public boolean deleteCommentGroupe(Long commentGroupeId) {

        Boolean result = false;
        try {

            if (commentGroupeId <= 0) {
                throw new Exception();
            }
            commentGroupeRepository.deleteById(commentGroupeId);

            result = true;

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return result;
    }

}
