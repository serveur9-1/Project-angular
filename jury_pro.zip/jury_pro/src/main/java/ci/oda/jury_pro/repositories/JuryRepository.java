package ci.oda.jury_pro.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ci.oda.jury_pro.entities.Jury;

public interface JuryRepository extends JpaRepository<Jury, Long> {

    @Query(value = "SELECT * FROM jury	 WHERE evenement_evenement_id = :evenementId", nativeQuery = true)
    List<Jury> findJuryByEventId(@Param("evenementId") Long evenementId);

    @Query(value = "SELECT COALESCE(jury_id,0) FROM `jury` WHERE jury_telephone = :juryTelephone", nativeQuery = true)
    Long findJuryByTelephone(@Param("juryTelephone") Long juryTelephone);
}
