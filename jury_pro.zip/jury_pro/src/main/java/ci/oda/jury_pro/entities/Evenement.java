package ci.oda.jury_pro.entities;

import java.sql.Date;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "evenements")
public class Evenement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long evenementId;
    private String evenementNom;
    private String evenementType;
    @Lob
    private byte[] evenementPhoto;
    private Date evenementDateDebut;
    private Date evenementDateFin;

    public Evenement(Long evenementId, String evenementNom, String evenementType, byte[] evenementPhoto,
            Date evenementDateDebut, Date evenementDateFin, List<Candidats> candidatList) {
        this.evenementId = evenementId;
        this.evenementNom = evenementNom;
        this.evenementType = evenementType;
        this.evenementPhoto = evenementPhoto;
        this.evenementDateDebut = evenementDateDebut;
        this.evenementDateFin = evenementDateFin;
    }

    public Evenement() {
    }

    public Long getEvenementId() {
        return this.evenementId;
    }

    public void setEvenementId(Long evenementId) {
        this.evenementId = evenementId;
    }

    public String getEvenementNom() {
        return this.evenementNom;
    }

    public void setEvenementNom(String evenementNom) {
        this.evenementNom = evenementNom;
    }

    public String getEvenementType() {
        return this.evenementType;
    }

    public void setEvenementType(String evenementType) {
        this.evenementType = evenementType;
    }

    public byte[] getEvenementPhoto() {
        return this.evenementPhoto;
    }

    public void setEvenementPhoto(byte[] evenementPhoto) {
        this.evenementPhoto = evenementPhoto;
    }

    public Date getEvenementDateDebut() {
        return this.evenementDateDebut;
    }

    public void setEvenementDateDebut(Date evenementDateDebut) {
        this.evenementDateDebut = evenementDateDebut;
    }

    public Date getEvenementDateFin() {
        return this.evenementDateFin;
    }

    public void setEvenementDateFin(Date evenementDateFin) {
        this.evenementDateFin = evenementDateFin;
    }

    @Override
    public String toString() {
        return "{" + " evenementId='" + getEvenementId() + "'" + ", evenementNom='" + getEvenementNom() + "'"
                + ", evenementType='" + getEvenementType() + "'" + ", evenementPhoto='" + getEvenementPhoto() + "'"
                + ", evenementDateDebut='" + getEvenementDateDebut() + "'" + ", evenementDateFin='"
                + getEvenementDateFin() + "'" + "}";
    }

    public void setEvenement_photo(byte[] bytes) {
    }

}
