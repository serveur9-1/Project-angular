package ci.oda.jury_pro.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import ci.oda.jury_pro.entities.Evenement;
import ci.oda.jury_pro.services.IParticipantService;

public interface EvenementsRepository extends JpaRepository<Evenement, Long> {

    @Query(value = "SELECT EV.*, COALESCE(GP.Nombre,0) as 'Participant' FROM evenements as EV LEFT OUTER JOIN (SELECT * FROM (SELECT CA.evenement_evenement_id, COUNT(*) AS nombre FROM candidats as CA GROUP BY CA.evenement_evenement_id) AS G1 UNION SELECT * FROM (SELECT GR.evenement_evenement_id , COUNT(*) AS nombre FROM groupes as GR GROUP BY GR.evenement_evenement_id) AS G2) AS GP ON (EV.evenement_id = GP.evenement_evenement_id)", nativeQuery = true)
    public List<IParticipantService> getNombreParticipants();

    @Query(value = "SELECT * FROM `evenements` WHERE evenement_id = (SELECT evenement_evenement_id FROM jury WHERE jury_id = :juryId)", nativeQuery = true)
    Evenement findByJuryId(@Param("juryId") Long juryId);

}
